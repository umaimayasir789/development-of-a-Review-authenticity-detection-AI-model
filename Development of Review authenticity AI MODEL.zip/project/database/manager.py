"""
Database manager for Review Authenticity Detection System
"""
from database.models import db, Review, DetectionResult, User, EmailPattern
from datetime import datetime, timedelta
import json
import re

class DatabaseManager:
    def __init__(self, app):
        self.app = app
        self.db = db
        db.init_app(app)
        
        with app.app_context():
            db.create_all()
    
    def create_review(self, user_id, email, text, rating, product_id):
        """Create a new review"""
        try:
            review = Review(
                user_id=user_id,
                email=email,
                text=text,
                rating=rating,
                product_id=product_id,
                timestamp=datetime.utcnow()
            )
            
            db.session.add(review)
            db.session.commit()
            
            # Update user statistics
            self.update_user_stats(user_id, email)
            
            return review
            
        except Exception as e:
            db.session.rollback()
            raise e
    
    def update_review_authenticity(self, review_id, detection_results):
        """Update review with authenticity results"""
        try:
            review = Review.query.get(review_id)
            if not review:
                return None
            
            # Update authenticity fields
            overall_auth = detection_results.get('overall_authenticity', {})
            ai_detection = detection_results.get('ai_detection', {})
            rep_detection = detection_results.get('repetitive_detection', {})
            bot_detection = detection_results.get('bot_detection', {})
            
            review.is_authentic = not overall_auth.get('is_fake', False)
            review.is_ai_generated = ai_detection.get('is_ai_generated', False)
            review.is_repetitive = rep_detection.get('is_repetitive', False)
            review.is_bot = bot_detection.get('is_bot', False)
            
            review.authenticity_score = overall_auth.get('fake_score', 0.0)
            review.ai_confidence = ai_detection.get('confidence', 0.0)
            review.repetitive_score = rep_detection.get('similarity', 0.0)
            review.bot_score = bot_detection.get('bot_score', 0.0)
            
            # Set status based on recommendation
            recommendation = detection_results.get('recommendation', '')
            if 'DELETE' in recommendation:
                review.status = 'deleted'
            elif 'FLAG' in recommendation:
                review.status = 'flagged'
            else:
                review.status = 'approved'
            
            # Store detailed results
            for detection_type, result in [
                ('ai', ai_detection),
                ('repetitive', rep_detection),
                ('bot', bot_detection)
            ]:
                detection_result = DetectionResult(
                    review_id=review.id,
                    detection_type=detection_type,
                    result=json.dumps(result),
                    timestamp=datetime.utcnow()
                )
                db.session.add(detection_result)
            
            db.session.commit()
            return review
            
        except Exception as e:
            db.session.rollback()
            raise e
    
    def get_user_review_history(self, user_id, limit=50):
        """Get user's review history"""
        try:
            reviews = Review.query.filter_by(user_id=user_id)\
                           .order_by(Review.timestamp.desc())\
                           .limit(limit)\
                           .all()
            
            return [{'text': r.text, 'timestamp': r.timestamp, 'rating': r.rating} 
                   for r in reviews]
            
        except Exception as e:
            print(f"Error getting user history: {e}")
            return []
    
    def get_user_data(self, user_id):
        """Get comprehensive user data for analysis"""
        try:
            user = User.query.filter_by(user_id=user_id).first()
            
            if not user:
                return {}
            
            # Calculate additional metrics
            recent_reviews = Review.query.filter_by(user_id=user_id)\
                                  .filter(Review.timestamp >= datetime.utcnow() - timedelta(days=1))\
                                  .count()
            
            # Get email patterns
            email_patterns = EmailPattern.query.filter_by(email=user.email).first()
            
            return {
                'account_age_days': (datetime.utcnow() - user.first_seen).days,
                'total_reviews': user.total_reviews,
                'flagged_reviews': user.flagged_reviews,
                'reviews_per_day': recent_reviews,
                'is_suspicious': user.is_suspicious,
                'is_blocked': user.is_blocked,
                'duplicate_emails': email_patterns.occurrences > 1 if email_patterns else False,
                'same_device_multiple_accounts': len(json.loads(user.devices)) > 1 if user.devices else False,
                'reviews_at_same_time': self.count_reviews_at_same_time(user_id)
            }
            
        except Exception as e:
            print(f"Error getting user data: {e}")
            return {}
    
    def count_reviews_at_same_time(self, user_id):
        """Count reviews posted at exactly the same time"""
        try:
            reviews = Review.query.filter_by(user_id=user_id).all()
            
            time_groups = {}
            for review in reviews:
                time_key = review.timestamp.strftime('%Y-%m-%d %H:%M')
                time_groups[time_key] = time_groups.get(time_key, 0) + 1
            
            return max(time_groups.values()) if time_groups else 0
            
        except Exception as e:
            print(f"Error counting same-time reviews: {e}")
            return 0
    
    def update_user_stats(self, user_id, email):
        """Update user statistics"""
        try:
            user = User.query.filter_by(user_id=user_id).first()
            
            if not user:
                user = User(
                    user_id=user_id,
                    email=email,
                    first_seen=datetime.utcnow(),
                    last_seen=datetime.utcnow()
                )
                db.session.add(user)
            else:
                user.last_seen = datetime.utcnow()
            
            user.total_reviews += 1
            
            # Update email patterns
            self.update_email_patterns(email)
            
            db.session.commit()
            
        except Exception as e:
            db.session.rollback()
            print(f"Error updating user stats: {e}")
    
    def update_email_patterns(self, email):
        """Update email pattern tracking"""
        try:
            pattern = EmailPattern.query.filter_by(email=email).first()
            
            if not pattern:
                # Check if it's a suspicious pattern
                pattern_type = self.analyze_email_pattern(email)
                
                pattern = EmailPattern(
                    email=email,
                    pattern_type=pattern_type,
                    occurrences=1,
                    first_seen=datetime.utcnow(),
                    last_seen=datetime.utcnow()
                )
                db.session.add(pattern)
            else:
                pattern.occurrences += 1
                pattern.last_seen = datetime.utcnow()
            
            db.session.commit()
            
        except Exception as e:
            db.session.rollback()
            print(f"Error updating email patterns: {e}")
    
    def analyze_email_pattern(self, email):
        """Analyze email for suspicious patterns"""
        try:
            # Check for generated patterns
            if re.search(r'\d{4,}', email):  # Long number sequences
                return 'generated'
            
            # Check for temporary email patterns
            temp_domains = ['10minutemail', 'guerrillamail', 'mailinator', 'tempmail']
            if any(domain in email.lower() for domain in temp_domains):
                return 'temporary'
            
            # Check for similar existing emails
            similar_emails = EmailPattern.query.filter(
                EmailPattern.email.like(f"{email.split('@')[0]}%")
            ).count()
            
            if similar_emails > 0:
                return 'duplicate'
            
            return 'normal'
            
        except Exception as e:
            print(f"Error analyzing email pattern: {e}")
            return 'normal'
    
    def delete_fake_reviews(self, review_ids):
        """Delete fake reviews from database"""
        try:
            deleted_count = 0
            
            for review_id in review_ids:
                review = Review.query.get(review_id)
                if review and review.status == 'deleted':
                    # Update user flagged count
                    user = User.query.filter_by(user_id=review.user_id).first()
                    if user:
                        user.flagged_reviews += 1
                        if user.flagged_reviews > 5:
                            user.is_suspicious = True
                    
                    # Actually delete the review
                    db.session.delete(review)
                    deleted_count += 1
            
            db.session.commit()
            return deleted_count
            
        except Exception as e:
            db.session.rollback()
            print(f"Error deleting fake reviews: {e}")
            return 0
    
    def get_reviews_for_deletion(self):
        """Get reviews marked for deletion"""
        try:
            reviews = Review.query.filter_by(status='deleted').all()
            return [r.to_dict() for r in reviews]
            
        except Exception as e:
            print(f"Error getting reviews for deletion: {e}")
            return []
    
    def get_flagged_reviews(self):
        """Get flagged reviews for manual review"""
        try:
            reviews = Review.query.filter_by(status='flagged').all()
            return [r.to_dict() for r in reviews]
            
        except Exception as e:
            print(f"Error getting flagged reviews: {e}")
            return []
    
    def get_analytics(self):
        """Get system analytics"""
        try:
            total_reviews = Review.query.count()
            authentic_reviews = Review.query.filter_by(is_authentic=True).count()
            fake_reviews = Review.query.filter_by(is_authentic=False).count()
            ai_generated = Review.query.filter_by(is_ai_generated=True).count()
            repetitive = Review.query.filter_by(is_repetitive=True).count()
            bot_reviews = Review.query.filter_by(is_bot=True).count()
            
            return {
                'total_reviews': total_reviews,
                'authentic_reviews': authentic_reviews,
                'fake_reviews': fake_reviews,
                'ai_generated': ai_generated,
                'repetitive': repetitive,
                'bot_reviews': bot_reviews,
                'authenticity_rate': (authentic_reviews / total_reviews * 100) if total_reviews > 0 else 0
            }
            
        except Exception as e:
            print(f"Error getting analytics: {e}")
            return {}