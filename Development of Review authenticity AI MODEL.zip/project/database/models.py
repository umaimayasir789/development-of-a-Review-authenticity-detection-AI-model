"""
Database models for Review Authenticity Detection System
"""
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class Review(db.Model):
    """Review model"""
    __tablename__ = 'reviews'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(200), nullable=False)
    text = db.Column(db.Text, nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    product_id = db.Column(db.String(100), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Authenticity fields
    is_authentic = db.Column(db.Boolean, default=True)
    is_ai_generated = db.Column(db.Boolean, default=False)
    is_repetitive = db.Column(db.Boolean, default=False)
    is_bot = db.Column(db.Boolean, default=False)
    
    # Scores
    authenticity_score = db.Column(db.Float, default=0.0)
    ai_confidence = db.Column(db.Float, default=0.0)
    repetitive_score = db.Column(db.Float, default=0.0)
    bot_score = db.Column(db.Float, default=0.0)
    
    # Status
    status = db.Column(db.String(50), default='pending')  # pending, approved, flagged, deleted
    
    # Relationships
    detection_results = db.relationship('DetectionResult', backref='review', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'email': self.email,
            'text': self.text,
            'rating': self.rating,
            'product_id': self.product_id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'is_authentic': self.is_authentic,
            'is_ai_generated': self.is_ai_generated,
            'is_repetitive': self.is_repetitive,
            'is_bot': self.is_bot,
            'authenticity_score': self.authenticity_score,
            'ai_confidence': self.ai_confidence,
            'repetitive_score': self.repetitive_score,
            'bot_score': self.bot_score,
            'status': self.status
        }

class DetectionResult(db.Model):
    """Detection result model"""
    __tablename__ = 'detection_results'
    
    id = db.Column(db.Integer, primary_key=True)
    review_id = db.Column(db.Integer, db.ForeignKey('reviews.id'), nullable=False)
    detection_type = db.Column(db.String(50), nullable=False)  # ai, repetitive, bot
    result = db.Column(db.Text, nullable=False)  # JSON string of results
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'review_id': self.review_id,
            'detection_type': self.detection_type,
            'result': json.loads(self.result) if self.result else {},
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }

class User(db.Model):
    """User model for tracking user behavior"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(200), nullable=False)
    first_seen = db.Column(db.DateTime, default=datetime.utcnow)
    last_seen = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Behavior tracking
    total_reviews = db.Column(db.Integer, default=0)
    flagged_reviews = db.Column(db.Integer, default=0)
    is_suspicious = db.Column(db.Boolean, default=False)
    is_blocked = db.Column(db.Boolean, default=False)
    
    # Device/IP tracking
    ip_addresses = db.Column(db.Text, default='[]')  # JSON array
    devices = db.Column(db.Text, default='[]')  # JSON array
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'email': self.email,
            'first_seen': self.first_seen.isoformat() if self.first_seen else None,
            'last_seen': self.last_seen.isoformat() if self.last_seen else None,
            'total_reviews': self.total_reviews,
            'flagged_reviews': self.flagged_reviews,
            'is_suspicious': self.is_suspicious,
            'is_blocked': self.is_blocked,
            'ip_addresses': json.loads(self.ip_addresses) if self.ip_addresses else [],
            'devices': json.loads(self.devices) if self.devices else []
        }

class EmailPattern(db.Model):
    """Email pattern tracking for duplicate detection"""
    __tablename__ = 'email_patterns'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(200), nullable=False)
    pattern_type = db.Column(db.String(50), nullable=False)  # duplicate, generated, suspicious
    occurrences = db.Column(db.Integer, default=1)
    first_seen = db.Column(db.DateTime, default=datetime.utcnow)
    last_seen = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'pattern_type': self.pattern_type,
            'occurrences': self.occurrences,
            'first_seen': self.first_seen.isoformat() if self.first_seen else None,
            'last_seen': self.last_seen.isoformat() if self.last_seen else None
        }