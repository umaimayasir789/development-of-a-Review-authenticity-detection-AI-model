"""
Main Review Authenticity Detection Model
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
import torch
import re
import pickle
import os
from datetime import datetime
import joblib

class ReviewAuthenticityDetector:
    def __init__(self, config):
        self.config = config
        self.tokenizer = None
        self.bert_model = None
        self.tfidf_vectorizer = None
        self.ml_classifier = None
        self.ensemble_model = None
        self.is_trained = False
        
    def initialize_models(self):
        """Initialize pre-trained models"""
        try:
            # Initialize BERT model for text classification
            self.tokenizer = AutoTokenizer.from_pretrained(self.config.PRETRAINED_MODEL)
            self.bert_model = pipeline(
                "text-classification",
                model=self.config.PRETRAINED_MODEL,
                tokenizer=self.tokenizer,
                return_all_scores=True
            )
            
            # Initialize TF-IDF vectorizer
            self.tfidf_vectorizer = TfidfVectorizer(
                max_features=10000,
                ngram_range=(1, 3),
                stop_words='english'
            )
            
            print("Models initialized successfully")
            
        except Exception as e:
            print(f"Error initializing models: {e}")
            raise
    
    def extract_features(self, text):
        """Extract various features from review text"""
        features = {}
        
        # Basic text features
        features['length'] = len(text)
        features['word_count'] = len(text.split())
        features['sentence_count'] = len(text.split('.'))
        features['avg_word_length'] = np.mean([len(word) for word in text.split()])
        
        # Punctuation features
        features['exclamation_count'] = text.count('!')
        features['question_count'] = text.count('?')
        features['caps_ratio'] = sum(1 for c in text if c.isupper()) / len(text) if text else 0
        
        # Repetitive patterns
        words = text.lower().split()
        features['repeated_words'] = len(words) - len(set(words))
        
        # Sentiment and emotion indicators
        positive_words = ['good', 'great', 'excellent', 'amazing', 'perfect', 'love', 'best']
        negative_words = ['bad', 'terrible', 'awful', 'hate', 'worst', 'horrible']
        
        features['positive_words'] = sum(1 for word in words if word in positive_words)
        features['negative_words'] = sum(1 for word in words if word in negative_words)
        
        # Generic/template indicators
        generic_phrases = ['highly recommend', 'customer service', 'money back', 'free shipping']
        features['generic_phrases'] = sum(1 for phrase in generic_phrases if phrase in text.lower())
        
        return features
    
    def detect_ai_generated(self, text):
        """Detect if text is AI-generated using multiple approaches"""
        try:
            # Method 1: BERT-based detection
            bert_score = self._bert_ai_detection(text)
            
            # Method 2: Pattern-based detection
            pattern_score = self._pattern_ai_detection(text)
            
            # Method 3: Linguistic analysis
            linguistic_score = self._linguistic_ai_detection(text)
            
            # Ensemble scoring
            final_score = (bert_score * 0.5 + pattern_score * 0.3 + linguistic_score * 0.2)
            
            return {
                'is_ai_generated': final_score > self.config.FAKE_THRESHOLD,
                'confidence': final_score,
                'bert_score': bert_score,
                'pattern_score': pattern_score,
                'linguistic_score': linguistic_score
            }
            
        except Exception as e:
            print(f"Error in AI detection: {e}")
            return {'is_ai_generated': False, 'confidence': 0.0}
    
    def _bert_ai_detection(self, text):
        """Use BERT model to detect AI-generated text"""
        try:
            # Truncate text if too long
            if len(text) > 500:
                text = text[:500]
            
            # Use BERT model for classification
            result = self.bert_model(text)
            
            # Assuming we have a binary classification (human vs AI)
            # This is a simplified approach - in practice, you'd need a model trained specifically for this
            ai_score = result[0][1]['score'] if len(result[0]) > 1 else 0.5
            
            return ai_score
            
        except Exception as e:
            print(f"Error in BERT AI detection: {e}")
            return 0.0
    
    def _pattern_ai_detection(self, text):
        """Detect AI patterns in text"""
        ai_indicators = 0
        total_indicators = 8
        
        # Check for overly formal language
        formal_words = ['furthermore', 'moreover', 'nevertheless', 'consequently']
        if any(word in text.lower() for word in formal_words):
            ai_indicators += 1
        
        # Check for repetitive sentence structures
        sentences = text.split('.')
        if len(sentences) > 2:
            similar_starts = sum(1 for i in range(len(sentences)-1) 
                               if sentences[i].strip()[:5] == sentences[i+1].strip()[:5])
            if similar_starts > 0:
                ai_indicators += 1
        
        # Check for lack of personal pronouns
        personal_pronouns = ['i', 'me', 'my', 'we', 'us', 'our']
        if not any(pronoun in text.lower() for pronoun in personal_pronouns):
            ai_indicators += 1
        
        # Check for perfect grammar (no common errors)
        common_errors = ["dont", "cant", "wont", "im", "youre", "its amazing"]
        if not any(error in text.lower() for error in common_errors):
            ai_indicators += 1
        
        # Check for balanced sentiment
        features = self.extract_features(text)
        if features['positive_words'] > 0 and features['negative_words'] > 0:
            ai_indicators += 1
        
        # Check for generic phrases
        if features['generic_phrases'] > 2:
            ai_indicators += 1
        
        # Check for unusual punctuation patterns
        if text.count('!') == 0 and text.count('?') == 0:
            ai_indicators += 1
        
        # Check for overly structured content
        if len(text.split('\n')) > 3:  # Multiple paragraphs
            ai_indicators += 1
        
        return ai_indicators / total_indicators
    
    def _linguistic_ai_detection(self, text):
        """Analyze linguistic patterns for AI detection"""
        features = self.extract_features(text)
        
        # AI tends to have more consistent patterns
        consistency_score = 0
        
        # Check average word length consistency
        words = text.split()
        if len(words) > 5:
            word_lengths = [len(word) for word in words]
            length_variance = np.var(word_lengths)
            if length_variance < 5:  # Low variance indicates consistency
                consistency_score += 0.3
        
        # Check sentence length consistency
        sentences = [s.strip() for s in text.split('.') if s.strip()]
        if len(sentences) > 2:
            sentence_lengths = [len(s.split()) for s in sentences]
            if sentence_lengths and np.var(sentence_lengths) < 10:
                consistency_score += 0.3
        
        # Check for balanced emotional expression
        if features['positive_words'] > 0 and features['negative_words'] > 0:
            ratio = features['positive_words'] / (features['positive_words'] + features['negative_words'])
            if 0.4 < ratio < 0.6:  # Balanced sentiment
                consistency_score += 0.4
        
        return consistency_score
    
    def detect_repetitive_user(self, user_id, text, user_reviews_history):
        """Detect repetitive reviews from same user"""
        try:
            if not user_reviews_history:
                return {'is_repetitive': False, 'similarity': 0.0}
            
            # Calculate similarity with previous reviews
            similarities = []
            for prev_review in user_reviews_history:
                similarity = self._calculate_text_similarity(text, prev_review['text'])
                similarities.append(similarity)
            
            max_similarity = max(similarities) if similarities else 0
            
            return {
                'is_repetitive': max_similarity > self.config.REPETITIVE_THRESHOLD,
                'similarity': max_similarity,
                'similar_reviews_count': sum(1 for sim in similarities if sim > 0.7)
            }
            
        except Exception as e:
            print(f"Error in repetitive detection: {e}")
            return {'is_repetitive': False, 'similarity': 0.0}
    
    def _calculate_text_similarity(self, text1, text2):
        """Calculate similarity between two texts"""
        try:
            # Simple approach using TF-IDF
            vectorizer = TfidfVectorizer(stop_words='english')
            tfidf_matrix = vectorizer.fit_transform([text1, text2])
            
            # Calculate cosine similarity
            similarity = np.dot(tfidf_matrix[0].toarray(), tfidf_matrix[1].toarray().T)[0][0]
            
            return similarity
            
        except Exception as e:
            print(f"Error calculating similarity: {e}")
            return 0.0
    
    def detect_bot_patterns(self, user_data):
        """Detect bot-like patterns in user behavior"""
        try:
            bot_indicators = 0
            total_indicators = 6
            
            # Check review frequency
            if user_data.get('reviews_per_day', 0) > self.config.MAX_REVIEWS_PER_USER_PER_DAY:
                bot_indicators += 1
            
            # Check review timing patterns
            if user_data.get('reviews_at_same_time', 0) > 3:
                bot_indicators += 1
            
            # Check for duplicate emails
            if user_data.get('duplicate_emails', False):
                bot_indicators += 1
            
            # Check account age vs review activity
            if user_data.get('account_age_days', 0) < 1 and user_data.get('total_reviews', 0) > 10:
                bot_indicators += 1
            
            # Check for similar device/IP patterns
            if user_data.get('same_device_multiple_accounts', False):
                bot_indicators += 1
            
            # Check for unrealistic review patterns
            if user_data.get('all_positive_reviews', False) or user_data.get('all_negative_reviews', False):
                bot_indicators += 1
            
            bot_score = bot_indicators / total_indicators
            
            return {
                'is_bot': bot_score > 0.5,
                'bot_score': bot_score,
                'indicators': bot_indicators
            }
            
        except Exception as e:
            print(f"Error in bot detection: {e}")
            return {'is_bot': False, 'bot_score': 0.0}
    
    def train_model(self, training_data):
        """Train the machine learning model"""
        try:
            # Prepare features
            X = []
            y = []
            
            for review in training_data:
                features = self.extract_features(review['text'])
                X.append(list(features.values()))
                y.append(review['is_fake'])
            
            X = np.array(X)
            y = np.array(y)
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # Train classifier
            self.ml_classifier = RandomForestClassifier(n_estimators=100, random_state=42)
            self.ml_classifier.fit(X_train, y_train)
            
            # Evaluate model
            y_pred = self.ml_classifier.predict(X_test)
            
            print("Model Training Complete")
            print(classification_report(y_test, y_pred))
            
            self.is_trained = True
            
            return {
                'accuracy': self.ml_classifier.score(X_test, y_test),
                'classification_report': classification_report(y_test, y_pred, output_dict=True)
            }
            
        except Exception as e:
            print(f"Error training model: {e}")
            return None
    
    def predict_authenticity(self, review_text, user_id=None, user_data=None, user_history=None):
        """Main prediction method"""
        try:
            results = {
                'timestamp': datetime.now().isoformat(),
                'review_text': review_text[:100] + '...' if len(review_text) > 100 else review_text,
                'user_id': user_id
            }
            
            # AI-generated detection
            ai_result = self.detect_ai_generated(review_text)
            results['ai_detection'] = ai_result
            
            # Repetitive user detection
            if user_history:
                rep_result = self.detect_repetitive_user(user_id, review_text, user_history)
                results['repetitive_detection'] = rep_result
            else:
                results['repetitive_detection'] = {'is_repetitive': False, 'similarity': 0.0}
            
            # Bot pattern detection
            if user_data:
                bot_result = self.detect_bot_patterns(user_data)
                results['bot_detection'] = bot_result
            else:
                results['bot_detection'] = {'is_bot': False, 'bot_score': 0.0}
            
            # Overall authenticity score
            overall_fake_score = (
                ai_result['confidence'] * 0.4 +
                results['repetitive_detection']['similarity'] * 0.3 +
                results['bot_detection']['bot_score'] * 0.3
            )
            
            results['overall_authenticity'] = {
                'is_fake': overall_fake_score > self.config.FAKE_THRESHOLD,
                'fake_score': overall_fake_score,
                'confidence': min(1.0, overall_fake_score + 0.1)
            }
            
            # Recommendation
            if results['overall_authenticity']['is_fake']:
                if ai_result['is_ai_generated']:
                    results['recommendation'] = 'DELETE - AI Generated'
                elif results['repetitive_detection']['is_repetitive']:
                    results['recommendation'] = 'DELETE - Repetitive Content'
                elif results['bot_detection']['is_bot']:
                    results['recommendation'] = 'DELETE - Bot Activity'
                else:
                    results['recommendation'] = 'FLAG - Suspicious Activity'
            else:
                results['recommendation'] = 'APPROVE - Authentic Review'
            
            return results
            
        except Exception as e:
            print(f"Error in prediction: {e}")
            return {'error': str(e)}
    
    def save_model(self, filepath):
        """Save trained model"""
        try:
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            
            model_data = {
                'ml_classifier': self.ml_classifier,
                'tfidf_vectorizer': self.tfidf_vectorizer,
                'config': self.config,
                'is_trained': self.is_trained
            }
            
            joblib.dump(model_data, filepath)
            print(f"Model saved to {filepath}")
            
        except Exception as e:
            print(f"Error saving model: {e}")
    
    def load_model(self, filepath):
        """Load trained model"""
        try:
            model_data = joblib.load(filepath)
            
            self.ml_classifier = model_data['ml_classifier']
            self.tfidf_vectorizer = model_data['tfidf_vectorizer']
            self.is_trained = model_data['is_trained']
            
            print(f"Model loaded from {filepath}")
            
        except Exception as e:
            print(f"Error loading model: {e}")