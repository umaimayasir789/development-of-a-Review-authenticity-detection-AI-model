"""
Flask API for Review Authenticity Detection System
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime
import os
import logging

from config import config
from models.fake_review_detector import ReviewAuthenticityDetector
from database.manager import DatabaseManager

def create_app(config_name='default'):
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    
    # Enable CORS
    CORS(app)
    
    # Initialize components
    detector = ReviewAuthenticityDetector(app.config)
    detector.initialize_models()
    
    db_manager = DatabaseManager(app)
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    @app.route('/health', methods=['GET'])
    def health_check():
        """Health check endpoint"""
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'version': '1.0.0'
        })
    
    @app.route('/api/analyze-review', methods=['POST'])
    def analyze_review():
        """Analyze a single review for authenticity"""
        try:
            data = request.get_json()
            
            # Validate input
            required_fields = ['text', 'user_id', 'email', 'rating', 'product_id']
            for field in required_fields:
                if field not in data:
                    return jsonify({'error': f'Missing required field: {field}'}), 400
            
            # Create review in database
            review = db_manager.create_review(
                user_id=data['user_id'],
                email=data['email'],
                text=data['text'],
                rating=data['rating'],
                product_id=data['product_id']
            )
            
            # Get user data and history
            user_data = db_manager.get_user_data(data['user_id'])
            user_history = db_manager.get_user_review_history(data['user_id'])
            
            # Analyze authenticity
            results = detector.predict_authenticity(
                review_text=data['text'],
                user_id=data['user_id'],
                user_data=user_data,
                user_history=user_history
            )
            
            # Update review with results
            updated_review = db_manager.update_review_authenticity(review.id, results)
            
            # Prepare response
            response = {
                'review_id': review.id,
                'analysis_results': results,
                'review_status': updated_review.status,
                'timestamp': datetime.now().isoformat()
            }
            
            return jsonify(response)
            
        except Exception as e:
            logger.error(f"Error analyzing review: {e}")
            return jsonify({'error': 'Internal server error'}), 500
    
    @app.route('/api/bulk-analyze', methods=['POST'])
    def bulk_analyze():
        """Analyze multiple reviews"""
        try:
            data = request.get_json()
            reviews = data.get('reviews', [])
            
            if not reviews:
                return jsonify({'error': 'No reviews provided'}), 400
            
            results = []
            
            for review_data in reviews:
                # Validate each review
                required_fields = ['text', 'user_id', 'email', 'rating', 'product_id']
                if not all(field in review_data for field in required_fields):
                    continue
                
                # Create review
                review = db_manager.create_review(
                    user_id=review_data['user_id'],
                    email=review_data['email'],
                    text=review_data['text'],
                    rating=review_data['rating'],
                    product_id=review_data['product_id']
                )
                
                # Get user data and history
                user_data = db_manager.get_user_data(review_data['user_id'])
                user_history = db_manager.get_user_review_history(review_data['user_id'])
                
                # Analyze authenticity
                analysis_results = detector.predict_authenticity(
                    review_text=review_data['text'],
                    user_id=review_data['user_id'],
                    user_data=user_data,
                    user_history=user_history
                )
                
                # Update review with results
                updated_review = db_manager.update_review_authenticity(review.id, analysis_results)
                
                results.append({
                    'review_id': review.id,
                    'analysis_results': analysis_results,
                    'review_status': updated_review.status
                })
            
            return jsonify({
                'processed_count': len(results),
                'results': results,
                'timestamp': datetime.now().isoformat()
            })
            
        except Exception as e:
            logger.error(f"Error in bulk analysis: {e}")
            return jsonify({'error': 'Internal server error'}), 500
    
    @app.route('/api/delete-fake-reviews', methods=['POST'])
    def delete_fake_reviews():
        """Delete fake reviews from database"""
        try:
            # Get reviews marked for deletion
            reviews_to_delete = db_manager.get_reviews_for_deletion()
            
            if not reviews_to_delete:
                return jsonify({'message': 'No reviews to delete', 'deleted_count': 0})
            
            review_ids = [r['id'] for r in reviews_to_delete]
            deleted_count = db_manager.delete_fake_reviews(review_ids)
            
            return jsonify({
                'message': f'Deleted {deleted_count} fake reviews',
                'deleted_count': deleted_count,
                'timestamp': datetime.now().isoformat()
            })
            
        except Exception as e:
            logger.error(f"Error deleting fake reviews: {e}")
            return jsonify({'error': 'Internal server error'}), 500
    
    @app.route('/api/flagged-reviews', methods=['GET'])
    def get_flagged_reviews():
        """Get flagged reviews for manual review"""
        try:
            flagged_reviews = db_manager.get_flagged_reviews()
            
            return jsonify({
                'flagged_reviews': flagged_reviews,
                'count': len(flagged_reviews),
                'timestamp': datetime.now().isoformat()
            })
            
        except Exception as e:
            logger.error(f"Error getting flagged reviews: {e}")
            return jsonify({'error': 'Internal server error'}), 500
    
    @app.route('/api/analytics', methods=['GET'])
    def get_analytics():
        """Get system analytics"""
        try:
            analytics = db_manager.get_analytics()
            
            return jsonify({
                'analytics': analytics,
                'timestamp': datetime.now().isoformat()
            })
            
        except Exception as e:
            logger.error(f"Error getting analytics: {e}")
            return jsonify({'error': 'Internal server error'}), 500
    
    @app.route('/api/user-analysis/<user_id>', methods=['GET'])
    def get_user_analysis(user_id):
        """Get detailed user analysis"""
        try:
            user_data = db_manager.get_user_data(user_id)
            user_history = db_manager.get_user_review_history(user_id)
            
            # Analyze user behavior
            bot_result = detector.detect_bot_patterns(user_data)
            
            return jsonify({
                'user_id': user_id,
                'user_data': user_data,
                'review_history_count': len(user_history),
                'bot_analysis': bot_result,
                'timestamp': datetime.now().isoformat()
            })
            
        except Exception as e:
            logger.error(f"Error getting user analysis: {e}")
            return jsonify({'error': 'Internal server error'}), 500
    
    @app.route('/api/train-model', methods=['POST'])
    def train_model():
        """Train the machine learning model with new data"""
        try:
            data = request.get_json()
            training_data = data.get('training_data', [])
            
            if not training_data:
                return jsonify({'error': 'No training data provided'}), 400
            
            # Train the model
            training_results = detector.train_model(training_data)
            
            if training_results:
                # Save the trained model
                model_path = os.path.join(app.config['MODEL_PATH'], 'trained_model.pkl')
                detector.save_model(model_path)
                
                return jsonify({
                    'message': 'Model trained successfully',
                    'training_results': training_results,
                    'timestamp': datetime.now().isoformat()
                })
            else:
                return jsonify({'error': 'Model training failed'}), 500
            
        except Exception as e:
            logger.error(f"Error training model: {e}")
            return jsonify({'error': 'Internal server error'}), 500
    
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({'error': 'Not found'}), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({'error': 'Internal server error'}), 500
    
    return app

if __name__ == '__main__':
    app = create_app('development')
    app.run(debug=True, host='0.0.0.0', port=5000)