"""
Demo script to test the API endpoints
"""
import requests
import json
import time
from datetime import datetime

API_BASE_URL = "http://localhost:5000"

def test_health():
    """Test health check endpoint"""
    try:
        response = requests.get(f"{API_BASE_URL}/health")
        print(f"Health Check: {response.status_code}")
        print(f"Response: {response.json()}")
        return response.status_code == 200
    except Exception as e:
        print(f"Health check failed: {e}")
        return False

def test_analyze_review():
    """Test single review analysis"""
    try:
        # Test with a real review
        real_review = {
            "text": "I love this product! It works great and the quality is excellent. Fast shipping too!",
            "user_id": "user_123",
            "email": "john@example.com",
            "rating": 5,
            "product_id": "prod_456"
        }
        
        response = requests.post(f"{API_BASE_URL}/api/analyze-review", json=real_review)
        print(f"\nReal Review Analysis: {response.status_code}")
        if response.status_code == 200:
            result = response.json()
            print(f"Recommendation: {result['analysis_results']['recommendation']}")
            print(f"Overall Score: {result['analysis_results']['overall_authenticity']['fake_score']:.2f}")
        
        # Test with a fake review
        fake_review = {
            "text": "This product demonstrates exceptional quality and craftsmanship that is immediately apparent upon inspection. I highly recommend this product to anyone who is looking for a high-quality solution.",
            "user_id": "user_789",
            "email": "fake@example.com",
            "rating": 5,
            "product_id": "prod_456"
        }
        
        response = requests.post(f"{API_BASE_URL}/api/analyze-review", json=fake_review)
        print(f"\nFake Review Analysis: {response.status_code}")
        if response.status_code == 200:
            result = response.json()
            print(f"Recommendation: {result['analysis_results']['recommendation']}")
            print(f"Overall Score: {result['analysis_results']['overall_authenticity']['fake_score']:.2f}")
        
        return True
        
    except Exception as e:
        print(f"Review analysis test failed: {e}")
        return False

def test_bulk_analyze():
    """Test bulk review analysis"""
    try:
        reviews = [
            {
                "text": "Great product! Works perfectly.",
                "user_id": "user_001",
                "email": "user1@example.com",
                "rating": 5,
                "product_id": "prod_001"
            },
            {
                "text": "This product is absolutely phenomenal and exceeds all expectations in every conceivable way possible.",
                "user_id": "user_002",
                "email": "user2@example.com",
                "rating": 5,
                "product_id": "prod_001"
            },
            {
                "text": "Good product, works as expected.",
                "user_id": "user_003",
                "email": "user3@example.com",
                "rating": 4,
                "product_id": "prod_001"
            }
        ]
        
        response = requests.post(f"{API_BASE_URL}/api/bulk-analyze", json={"reviews": reviews})
        print(f"\nBulk Analysis: {response.status_code}")
        if response.status_code == 200:
            result = response.json()
            print(f"Processed: {result['processed_count']} reviews")
            
            for i, res in enumerate(result['results']):
                print(f"Review {i+1}: {res['analysis_results']['recommendation']}")
        
        return True
        
    except Exception as e:
        print(f"Bulk analysis test failed: {e}")
        return False

def test_analytics():
    """Test analytics endpoint"""
    try:
        response = requests.get(f"{API_BASE_URL}/api/analytics")
        print(f"\nAnalytics: {response.status_code}")
        if response.status_code == 200:
            result = response.json()
            analytics = result['analytics']
            print(f"Total Reviews: {analytics.get('total_reviews', 0)}")
            print(f"Authentic Reviews: {analytics.get('authentic_reviews', 0)}")
            print(f"Fake Reviews: {analytics.get('fake_reviews', 0)}")
            print(f"Authenticity Rate: {analytics.get('authenticity_rate', 0):.1f}%")
        
        return True
        
    except Exception as e:
        print(f"Analytics test failed: {e}")
        return False

def test_flagged_reviews():
    """Test flagged reviews endpoint"""
    try:
        response = requests.get(f"{API_BASE_URL}/api/flagged-reviews")
        print(f"\nFlagged Reviews: {response.status_code}")
        if response.status_code == 200:
            result = response.json()
            print(f"Flagged Reviews Count: {result['count']}")
        
        return True
        
    except Exception as e:
        print(f"Flagged reviews test failed: {e}")
        return False

def test_delete_fake_reviews():
    """Test delete fake reviews endpoint"""
    try:
        response = requests.post(f"{API_BASE_URL}/api/delete-fake-reviews")
        print(f"\nDelete Fake Reviews: {response.status_code}")
        if response.status_code == 200:
            result = response.json()
            print(f"Message: {result['message']}")
            print(f"Deleted Count: {result['deleted_count']}")
        
        return True
        
    except Exception as e:
        print(f"Delete fake reviews test failed: {e}")
        return False

def run_demo():
    """Run complete API demo"""
    print("Starting Review Authenticity Detection API Demo")
    print("=" * 50)
    
    # Test endpoints
    tests = [
        ("Health Check", test_health),
        ("Analyze Review", test_analyze_review),
        ("Bulk Analyze", test_bulk_analyze),
        ("Analytics", test_analytics),
        ("Flagged Reviews", test_flagged_reviews),
        ("Delete Fake Reviews", test_delete_fake_reviews)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\nRunning {test_name}...")
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"Error in {test_name}: {e}")
            results.append((test_name, False))
        
        time.sleep(1)  # Brief pause between tests
    
    # Summary
    print("\n" + "=" * 50)
    print("Demo Results Summary:")
    print("=" * 50)
    
    for test_name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"{test_name}: {status}")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    print(f"\nOverall: {passed}/{total} tests passed")

if __name__ == "__main__":
    run_demo()