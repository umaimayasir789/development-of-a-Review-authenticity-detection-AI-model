"""
Training script for Review Authenticity Detection Model
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

from models.fake_review_detector import ReviewAuthenticityDetector
from config import Config

def generate_synthetic_data():
    """Generate synthetic training data for demonstration"""
    
    # Real review examples
    real_reviews = [
        "I love this product! It works exactly as described and arrived quickly.",
        "Great quality for the price. My family really enjoys using it.",
        "Not bad, but could be better. The material feels a bit cheap.",
        "Excellent customer service. Had an issue and they resolved it immediately.",
        "Perfect! Exactly what I was looking for. Highly recommend.",
        "Good value for money. Works well and looks nice too.",
        "I'm really happy with this purchase. It exceeded my expectations.",
        "Decent product, nothing special but does the job well.",
        "Love it! Will definitely buy again and recommend to friends.",
        "Fair product for the price point. Does what it says."
    ]
    
    # Fake/AI-generated review examples
    fake_reviews = [
        "This product is absolutely phenomenal and exceeds all expectations in every conceivable way possible.",
        "I highly recommend this product to anyone who is looking for a high-quality solution.",
        "The product features excellent craftsmanship and superior build quality that is immediately apparent.",
        "This is an outstanding product that delivers exceptional value and performance consistently.",
        "I am extremely satisfied with this purchase and would definitely recommend it to others.",
        "The product arrived promptly and was exactly as described in the listing.",
        "This is a fantastic product that offers great value for money and excellent functionality.",
        "I am very pleased with this product and it has exceeded my expectations completely.",
        "The quality is excellent and the price is very reasonable for what you get.",
        "This product is highly recommended and I would purchase it again without hesitation."
    ]
    
    # Create dataset
    data = []
    
    # Add real reviews
    for review in real_reviews:
        data.append({
            'text': review,
            'is_fake': False,
            'user_id': f'user_{np.random.randint(1000, 9999)}',
            'email': f'user{np.random.randint(1, 100)}@email.com',
            'rating': np.random.randint(3, 6),
            'product_id': f'prod_{np.random.randint(100, 999)}'
        })
    
    # Add fake reviews
    for review in fake_reviews:
        data.append({
            'text': review,
            'is_fake': True,
            'user_id': f'user_{np.random.randint(1000, 9999)}',
            'email': f'user{np.random.randint(1, 100)}@email.com',
            'rating': np.random.randint(1, 6),
            'product_id': f'prod_{np.random.randint(100, 999)}'
        })
    
    # Add repetitive reviews (same user, similar content)
    user_id = 'user_repetitive'
    base_review = "This product is good and I like it very much."
    variations = [
        "This product is good and I like it very much.",
        "This product is great and I like it very much.",
        "This product is excellent and I like it very much.",
        "This product is amazing and I like it very much.",
        "This product is wonderful and I like it very much."
    ]
    
    for i, review in enumerate(variations):
        data.append({
            'text': review,
            'is_fake': True,
            'user_id': user_id,
            'email': 'repetitive@email.com',
            'rating': 5,
            'product_id': f'prod_{i}'
        })
    
    return data

def train_model():
    """Train the authenticity detection model"""
    
    print("Starting model training...")
    
    # Initialize detector
    config = Config()
    detector = ReviewAuthenticityDetector(config)
    detector.initialize_models()
    
    # Generate training data
    print("Generating synthetic training data...")
    training_data = generate_synthetic_data()
    
    print(f"Training data size: {len(training_data)}")
    print(f"Fake reviews: {sum(1 for d in training_data if d['is_fake'])}")
    print(f"Real reviews: {sum(1 for d in training_data if not d['is_fake'])}")
    
    # Train the model
    print("Training model...")
    training_results = detector.train_model(training_data)
    
    if training_results:
        print(f"Training completed successfully!")
        print(f"Model accuracy: {training_results['accuracy']:.2f}")
        
        # Save the model
        model_path = 'models/trained_model.pkl'
        os.makedirs('models', exist_ok=True)
        detector.save_model(model_path)
        print(f"Model saved to {model_path}")
        
        # Test the model with some examples
        print("\nTesting model with examples:")
        
        test_examples = [
            "I love this product! It works great and I'm very happy with it.",
            "This product is absolutely phenomenal and exceeds all expectations in every conceivable way possible.",
            "Good product, works as expected. Nothing fancy but does the job.",
            "I highly recommend this product to anyone who is looking for a high-quality solution."
        ]
        
        for i, example in enumerate(test_examples):
            result = detector.predict_authenticity(example)
            print(f"\nExample {i+1}: {example[:50]}...")
            print(f"Prediction: {result['recommendation']}")
            print(f"Confidence: {result['overall_authenticity']['confidence']:.2f}")
        
        return True
    else:
        print("Model training failed!")
        return False

if __name__ == "__main__":
    success = train_model()
    if success:
        print("\nTraining completed successfully!")
    else:
        print("\nTraining failed!")