"""
Model evaluation script for Review Authenticity Detection
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import seaborn as sns

from models.fake_review_detector import ReviewAuthenticityDetector
from config import Config

def evaluate_model():
    """Evaluate the trained model"""
    
    print("Starting model evaluation...")
    
    # Initialize detector
    config = Config()
    detector = ReviewAuthenticityDetector(config)
    detector.initialize_models()
    
    # Load trained model
    model_path = 'models/trained_model.pkl'
    if os.path.exists(model_path):
        detector.load_model(model_path)
        print("Loaded trained model")
    else:
        print("No trained model found. Please train the model first.")
        return False
    
    # Generate test data
    test_data = generate_test_data()
    
    print(f"Test data size: {len(test_data)}")
    
    # Evaluate model
    predictions = []
    actuals = []
    
    for item in test_data:
        result = detector.predict_authenticity(item['text'])
        
        # Get prediction
        is_fake_pred = result['overall_authenticity']['is_fake']
        confidence = result['overall_authenticity']['confidence']
        
        predictions.append({
            'text': item['text'][:50] + '...',
            'actual': item['is_fake'],
            'predicted': is_fake_pred,
            'confidence': confidence,
            'ai_score': result['ai_detection']['confidence'],
            'recommendation': result['recommendation']
        })
        
        actuals.append(item['is_fake'])
    
    # Calculate metrics
    predicted_labels = [p['predicted'] for p in predictions]
    confidence_scores = [p['confidence'] for p in predictions]
    
    # Classification report
    print("\nClassification Report:")
    print(classification_report(actuals, predicted_labels))
    
    # Confusion matrix
    cm = confusion_matrix(actuals, predicted_labels)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['Real', 'Fake'], 
                yticklabels=['Real', 'Fake'])
    plt.title('Confusion Matrix')
    plt.ylabel('Actual')
    plt.xlabel('Predicted')
    plt.tight_layout()
    plt.savefig('evaluation_results/confusion_matrix.png')
    plt.close()
    
    # ROC curve
    try:
        auc_score = roc_auc_score(actuals, confidence_scores)
        fpr, tpr, _ = roc_curve(actuals, confidence_scores)
        
        plt.figure(figsize=(8, 6))
        plt.plot(fpr, tpr, label=f'ROC Curve (AUC = {auc_score:.2f})')
        plt.plot([0, 1], [0, 1], 'k--', label='Random')
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC Curve')
        plt.legend()
        plt.tight_layout()
        plt.savefig('evaluation_results/roc_curve.png')
        plt.close()
        
        print(f"\nAUC Score: {auc_score:.3f}")
        
    except Exception as e:
        print(f"Error calculating ROC: {e}")
    
    # Detailed results
    print("\nDetailed Results:")
    print("-" * 80)
    
    df = pd.DataFrame(predictions)
    
    # Accuracy by type
    correct_predictions = df[df['actual'] == df['predicted']]
    accuracy = len(correct_predictions) / len(df)
    
    print(f"Overall Accuracy: {accuracy:.3f}")
    
    # False positives (Real reviews classified as fake)
    false_positives = df[(df['actual'] == False) & (df['predicted'] == True)]
    print(f"False Positives: {len(false_positives)}")
    
    # False negatives (Fake reviews classified as real)
    false_negatives = df[(df['actual'] == True) & (df['predicted'] == False)]
    print(f"False Negatives: {len(false_negatives)}")
    
    # Save detailed results
    os.makedirs('evaluation_results', exist_ok=True)
    df.to_csv('evaluation_results/detailed_results.csv', index=False)
    
    print("\nEvaluation completed! Results saved to evaluation_results/")
    
    return True

def generate_test_data():
    """Generate test data for evaluation"""
    
    # Real reviews
    real_reviews = [
        "Great product! Works perfectly and arrived on time.",
        "I'm happy with this purchase. Good quality for the price.",
        "Not impressed. The quality is poor and it broke after a week.",
        "Excellent! My kids love it and it's very durable.",
        "OK product, nothing special but gets the job done.",
        "Love it! Will definitely order again.",
        "Disappointed. Expected better quality for this price.",
        "Perfect! Exactly what I needed and fast shipping.",
        "Good value. Works as described and looks nice.",
        "Terrible quality. Would not recommend to anyone."
    ]
    
    # AI-generated/fake reviews
    fake_reviews = [
        "This product demonstrates exceptional quality and craftsmanship that is immediately apparent upon inspection.",
        "I am thoroughly impressed with the outstanding performance and reliability of this exceptional product.",
        "This product offers superior functionality and represents excellent value for the discerning consumer.",
        "The exceptional build quality and attention to detail make this product a standout choice.",
        "This product consistently delivers outstanding results and exceeds expectations in every aspect.",
        "I would highly recommend this product to anyone seeking a premium solution with exceptional quality.",
        "This product features innovative design and superior materials that ensure long-lasting performance.",
        "The exceptional customer service and product quality make this an outstanding purchasing experience.",
        "This product represents the pinnacle of quality and innovation in its category.",
        "I am extremely satisfied with this purchase and would confidently recommend it to others."
    ]
    
    # Repetitive reviews
    repetitive_reviews = [
        "This product is good and I like it.",
        "This product is great and I like it.",
        "This product is excellent and I like it.",
        "This product is amazing and I like it.",
        "This product is wonderful and I like it."
    ]
    
    test_data = []
    
    # Add real reviews
    for review in real_reviews:
        test_data.append({'text': review, 'is_fake': False})
    
    # Add fake reviews
    for review in fake_reviews:
        test_data.append({'text': review, 'is_fake': True})
    
    # Add repetitive reviews
    for review in repetitive_reviews:
        test_data.append({'text': review, 'is_fake': True})
    
    return test_data

if __name__ == "__main__":
    success = evaluate_model()
    if success:
        print("\nEvaluation completed successfully!")
    else:
        print("\nEvaluation failed!")