"""
Data preprocessing utilities for Review Authenticity Detection
"""
import pandas as pd
import numpy as np
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from textblob import TextBlob
from langdetect import detect
import string

# Download required NLTK data
try:
    nltk.download('punkt', quiet=True)
    nltk.download('stopwords', quiet=True)
    nltk.download('wordnet', quiet=True)
    nltk.download('omw-1.4', quiet=True)
except:
    print("Warning: Could not download NLTK data")

class TextPreprocessor:
    """Text preprocessing utilities"""
    
    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        try:
            self.stop_words = set(stopwords.words('english'))
        except:
            self.stop_words = set()
    
    def clean_text(self, text):
        """Clean and normalize text"""
        if not isinstance(text, str):
            return ""
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove URLs
        text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
        
        # Remove email addresses
        text = re.sub(r'\S+@\S+', '', text)
        
        # Remove HTML tags
        text = re.sub(r'<.*?>', '', text)
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove leading/trailing whitespace
        text = text.strip()
        
        return text
    
    def remove_punctuation(self, text):
        """Remove punctuation from text"""
        return text.translate(str.maketrans('', '', string.punctuation))
    
    def tokenize_text(self, text):
        """Tokenize text into words"""
        try:
            tokens = word_tokenize(text)
            return tokens
        except:
            return text.split()
    
    def remove_stopwords(self, tokens):
        """Remove stop words from tokens"""
        return [token for token in tokens if token not in self.stop_words]
    
    def lemmatize_tokens(self, tokens):
        """Lemmatize tokens"""
        try:
            return [self.lemmatizer.lemmatize(token) for token in tokens]
        except:
            return tokens
    
    def preprocess_text(self, text, remove_punctuation=True, remove_stopwords=True, lemmatize=True):
        """Complete text preprocessing pipeline"""
        # Clean text
        text = self.clean_text(text)
        
        # Remove punctuation if requested
        if remove_punctuation:
            text = self.remove_punctuation(text)
        
        # Tokenize
        tokens = self.tokenize_text(text)
        
        # Remove stopwords if requested
        if remove_stopwords:
            tokens = self.remove_stopwords(tokens)
        
        # Lemmatize if requested
        if lemmatize:
            tokens = self.lemmatize_tokens(tokens)
        
        return ' '.join(tokens)

class ReviewDataProcessor:
    """Review data processing utilities"""
    
    def __init__(self):
        self.preprocessor = TextPreprocessor()
    
    def extract_text_features(self, text):
        """Extract comprehensive text features"""
        features = {}
        
        if not isinstance(text, str) or not text:
            return self._empty_features()
        
        # Basic features
        features['char_count'] = len(text)
        features['word_count'] = len(text.split())
        features['sentence_count'] = len(text.split('.'))
        features['paragraph_count'] = len(text.split('\n'))
        
        # Average lengths
        words = text.split()
        features['avg_word_length'] = np.mean([len(word) for word in words]) if words else 0
        
        sentences = [s.strip() for s in text.split('.') if s.strip()]
        features['avg_sentence_length'] = np.mean([len(s.split()) for s in sentences]) if sentences else 0
        
        # Punctuation features
        features['exclamation_count'] = text.count('!')
        features['question_count'] = text.count('?')
        features['comma_count'] = text.count(',')
        features['period_count'] = text.count('.')
        features['semicolon_count'] = text.count(';')
        features['colon_count'] = text.count(':')
        
        # Case features
        features['uppercase_count'] = sum(1 for c in text if c.isupper())
        features['lowercase_count'] = sum(1 for c in text if c.islower())
        features['digit_count'] = sum(1 for c in text if c.isdigit())
        features['caps_ratio'] = features['uppercase_count'] / len(text) if text else 0
        
        # Linguistic features
        features.update(self._linguistic_features(text))
        
        # Sentiment features
        features.update(self._sentiment_features(text))
        
        # Repetition features
        features.update(self._repetition_features(text))
        
        # Readability features
        features.update(self._readability_features(text))
        
        return features
    
    def _empty_features(self):
        """Return empty features dictionary"""
        return {key: 0 for key in [
            'char_count', 'word_count', 'sentence_count', 'paragraph_count',
            'avg_word_length', 'avg_sentence_length', 'exclamation_count',
            'question_count', 'comma_count', 'period_count', 'semicolon_count',
            'colon_count', 'uppercase_count', 'lowercase_count', 'digit_count',
            'caps_ratio', 'pos_noun_ratio', 'pos_verb_ratio', 'pos_adj_ratio',
            'pos_adv_ratio', 'sentiment_polarity', 'sentiment_subjectivity',
            'positive_words', 'negative_words', 'repeated_words', 'repeated_bigrams',
            'repeated_trigrams', 'flesch_score', 'unique_word_ratio'
        ]}
    
    def _linguistic_features(self, text):
        """Extract linguistic features"""
        features = {}
        
        try:
            # POS tagging
            blob = TextBlob(text)
            pos_tags = blob.tags
            
            if pos_tags:
                noun_count = sum(1 for _, tag in pos_tags if tag.startswith('N'))
                verb_count = sum(1 for _, tag in pos_tags if tag.startswith('V'))
                adj_count = sum(1 for _, tag in pos_tags if tag.startswith('J'))
                adv_count = sum(1 for _, tag in pos_tags if tag.startswith('R'))
                
                total_tags = len(pos_tags)
                features['pos_noun_ratio'] = noun_count / total_tags if total_tags > 0 else 0
                features['pos_verb_ratio'] = verb_count / total_tags if total_tags > 0 else 0
                features['pos_adj_ratio'] = adj_count / total_tags if total_tags > 0 else 0
                features['pos_adv_ratio'] = adv_count / total_tags if total_tags > 0 else 0
            else:
                features['pos_noun_ratio'] = 0
                features['pos_verb_ratio'] = 0
                features['pos_adj_ratio'] = 0
                features['pos_adv_ratio'] = 0
                
        except:
            features['pos_noun_ratio'] = 0
            features['pos_verb_ratio'] = 0
            features['pos_adj_ratio'] = 0
            features['pos_adv_ratio'] = 0
        
        return features
    
    def _sentiment_features(self, text):
        """Extract sentiment features"""
        features = {}
        
        try:
            blob = TextBlob(text)
            features['sentiment_polarity'] = blob.sentiment.polarity
            features['sentiment_subjectivity'] = blob.sentiment.subjectivity
        except:
            features['sentiment_polarity'] = 0
            features['sentiment_subjectivity'] = 0
        
        # Word-based sentiment
        positive_words = ['good', 'great', 'excellent', 'amazing', 'perfect', 'love', 'best', 'wonderful', 'awesome', 'fantastic']
        negative_words = ['bad', 'terrible', 'awful', 'hate', 'worst', 'horrible', 'disappointing', 'poor', 'useless', 'garbage']
        
        words = text.lower().split()
        features['positive_words'] = sum(1 for word in words if word in positive_words)
        features['negative_words'] = sum(1 for word in words if word in negative_words)
        
        return features
    
    def _repetition_features(self, text):
        """Extract repetition features"""
        features = {}
        
        words = text.lower().split()
        
        # Word repetition
        word_counts = {}
        for word in words:
            word_counts[word] = word_counts.get(word, 0) + 1
        
        features['repeated_words'] = sum(count - 1 for count in word_counts.values() if count > 1)
        
        # Bigram repetition
        bigrams = [' '.join(words[i:i+2]) for i in range(len(words)-1)]
        bigram_counts = {}
        for bigram in bigrams:
            bigram_counts[bigram] = bigram_counts.get(bigram, 0) + 1
        
        features['repeated_bigrams'] = sum(count - 1 for count in bigram_counts.values() if count > 1)
        
        # Trigram repetition
        trigrams = [' '.join(words[i:i+3]) for i in range(len(words)-2)]
        trigram_counts = {}
        for trigram in trigrams:
            trigram_counts[trigram] = trigram_counts.get(trigram, 0) + 1
        
        features['repeated_trigrams'] = sum(count - 1 for count in trigram_counts.values() if count > 1)
        
        return features
    
    def _readability_features(self, text):
        """Extract readability features"""
        features = {}
        
        words = text.split()
        sentences = text.split('.')
        
        if len(words) > 0 and len(sentences) > 0:
            # Flesch reading ease approximation
            avg_sentence_length = len(words) / len(sentences)
            avg_syllables_per_word = self._estimate_syllables(text) / len(words)
            
            features['flesch_score'] = 206.835 - (1.015 * avg_sentence_length) - (84.6 * avg_syllables_per_word)
        else:
            features['flesch_score'] = 0
        
        # Lexical diversity
        unique_words = set(words)
        features['unique_word_ratio'] = len(unique_words) / len(words) if words else 0
        
        return features
    
    def _estimate_syllables(self, text):
        """Estimate syllable count in text"""
        words = text.lower().split()
        syllable_count = 0
        
        for word in words:
            syllable_count += self._count_syllables(word)
        
        return syllable_count
    
    def _count_syllables(self, word):
        """Count syllables in a word"""
        vowels = 'aeiouy'
        syllable_count = 0
        previous_was_vowel = False
        
        for char in word:
            if char in vowels:
                if not previous_was_vowel:
                    syllable_count += 1
                previous_was_vowel = True
            else:
                previous_was_vowel = False
        
        # Handle silent 'e'
        if word.endswith('e') and syllable_count > 1:
            syllable_count -= 1
        
        return max(1, syllable_count)
    
    def detect_language(self, text):
        """Detect language of text"""
        try:
            return detect(text)
        except:
            return 'unknown'
    
    def extract_email_features(self, email):
        """Extract features from email address"""
        features = {}
        
        if not isinstance(email, str):
            return {'email_length': 0, 'has_numbers': False, 'domain_suspicious': False}
        
        features['email_length'] = len(email)
        features['has_numbers'] = bool(re.search(r'\d', email))
        
        # Check for suspicious domains
        suspicious_domains = ['10minutemail', 'guerrillamail', 'mailinator', 'tempmail', 'throwaway']
        features['domain_suspicious'] = any(domain in email.lower() for domain in suspicious_domains)
        
        return features
    
    def process_review_dataset(self, df):
        """Process entire review dataset"""
        processed_data = []
        
        for index, row in df.iterrows():
            try:
                # Extract text features
                text_features = self.extract_text_features(row['text'])
                
                # Extract email features
                email_features = self.extract_email_features(row.get('email', ''))
                
                # Combine all features
                features = {
                    'review_id': row.get('id', index),
                    'user_id': row.get('user_id', ''),
                    'text': row['text'],
                    'rating': row.get('rating', 0),
                    'is_fake': row.get('is_fake', False),
                    **text_features,
                    **email_features
                }
                
                processed_data.append(features)
                
            except Exception as e:
                print(f"Error processing row {index}: {e}")
                continue
        
        return pd.DataFrame(processed_data)

# Utility functions
def load_review_data(file_path):
    """Load review data from file"""
    try:
        if file_path.endswith('.csv'):
            return pd.read_csv(file_path)
        elif file_path.endswith('.json'):
            return pd.read_json(file_path)
        else:
            raise ValueError("Unsupported file format")
    except Exception as e:
        print(f"Error loading data: {e}")
        return pd.DataFrame()

def save_processed_data(df, file_path):
    """Save processed data to file"""
    try:
        if file_path.endswith('.csv'):
            df.to_csv(file_path, index=False)
        elif file_path.endswith('.json'):
            df.to_json(file_path, orient='records', indent=2)
        else:
            raise ValueError("Unsupported file format")
        print(f"Data saved to {file_path}")
    except Exception as e:
        print(f"Error saving data: {e}")